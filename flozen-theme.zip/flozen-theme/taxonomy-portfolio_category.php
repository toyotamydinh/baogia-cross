<?php

defined('ABSPATH') or exit; // Exit if accessed directly
include_once FLOZEN_THEME_PATH . '/portfolio.php';
