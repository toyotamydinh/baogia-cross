<?php

// Option elements
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_01_general.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_02_logo_icon.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_03_header_footer.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_04_style_color.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_05_type.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_06_breadcrumb.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_07_1_product_global.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_07_2_product_archive.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_07_3_product_single.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_07_4_product_compare.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_08_blog.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_09_promo_popup.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_10_portfolio.php';
require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_11_promotion_news.php';
// require_once FLOZEN_THEME_PATH . '/admin/elements/nasa_12_backup_options.php';
