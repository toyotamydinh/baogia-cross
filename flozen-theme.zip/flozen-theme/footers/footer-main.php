    </div>
    <!-- MAIN FOOTER -->
    <?php do_action('nasa_footer_layout_style'); ?>
    <!-- END MAIN FOOTER -->
</div>
<?php wp_footer(); ?>
</body>
</html>