<div class="content-account">
    <?php echo flozen_tiny_account(true); ?>
</div>